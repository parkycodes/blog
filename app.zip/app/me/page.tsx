export default function Page() {
    return (
      <section>
        <h1 className="font-semibold text-2xl mb-8 tracking-tighter">About Me</h1>


        <p className="mb-4">
        {`I'm a student located in the DMV area who follows gods word
        and loves Pure Leaf Tea, aimed towards travelling to as many 
        places as I can after college and exploring what the world has to offer. 
        I want to make an impact that is beneficial for global 
        happieness and love. 

        `}
      </p>

      <p className="mb-4">
        {`Please connect with me!`}
      </p>
      </section>

      
    )
  }